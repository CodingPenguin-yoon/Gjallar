# Gjallar 문서

**목표는 PRD, 현재 모습은 아키텍처, 다음 할 일은 로드맵에서 확인합니다.**

갈랴르는 Proxmox 관리 화면을 오가지 않고 템플릿 준비·VM 관리·모니터링·복구를 한곳에서 끝내는 도구를 지향합니다. 현재는 관찰과 제한된 VM 작업이 구현되어 있습니다.

## 먼저 읽을 문서

| 문서 | 답하는 질문 |
|---|---|
| [PRD](prd.md) | 무엇을 누구를 위해 만들며, 핵심 가치는 무엇인가? |
| [아키텍처](architecture.md) | 지금 실제로 어떻게 동작하며, 어떤 제약이 있는가? |
| [로드맵](roadmap.md) | 어디까지 구현됐고 다음에 무엇을 정해야 하는가? |
| [개발·운영 안내](development.md) | 어떻게 설치·실행·테스트하고 장애를 확인하는가? |
| [작업 기록](work/README.md) | 무엇을 왜 바꿨고, 무엇을 검증했는가? |

## 폴더는 세 가지로 구분합니다

| 폴더 | 역할 | 넣지 않는 것 |
|---|---|---|
| [reference](reference/README.md) | 현재 API·DB·도메인·실행 복구 계약과 설계 결정 | 작업 일지·완료된 계획 |
| [work](work/README.md) | 앞으로 수행할 구체적인 계획과 의미 있는 작업 결과 | 제품 전체 로드맵의 복사본 |
| [archive](archive/README.md) | 이전 명세·종료 계획·과거 조사·검증 원본 | 현재 요구사항·새 실행 승인 |

작업 전 환경·위험·검증 기준은 [프로젝트 프로필](project-profile.md)에 있습니다.

## 문서 구조

```text
project-docs/
├── README.md                  # 문서 지도
├── prd.md                     # 무엇을 만드는가
├── architecture.md            # 현재 어떻게 동작하는가
├── roadmap.md                 # 현재 위치와 다음 일
├── development.md             # 설치·실행·검증·운영
├── project-profile.md         # 작업 전 환경·위험 기준
├── reference/
│   ├── README.md
│   ├── api.md
│   ├── database.md
│   ├── domains.md
│   ├── operation-lifecycle.md
│   └── decisions/             # 설계 결정과 대체 관계
├── work/
│   ├── README.md
│   ├── plans/                 # 진행할 구체적인 구현 계획
│   └── YYYY-MM-DD-topic.md    # 의미 있는 작업 결과
└── archive/
    ├── README.md
    ├── product/               # 이전 제품 명세
    ├── plans/                 # 종료된 구현 계획
    ├── assessments/           # 종료된 조사
    └── evidence/              # 과거 검증 원본
```

## 무엇이 바뀌면 어디를 수정하나요?

- 제품 목적·기능 범위가 바뀌면 **PRD**, 우선순위·진행 상태는 **로드맵**을 갱신합니다.
- 실제 구조는 **아키텍처**, 설치·검증 절차는 **개발 안내**를 갱신합니다.
- API·DB·복구 등 세부 계약만 바뀌면 **reference의 해당 문서**를 갱신합니다.
- 구현 전 상세 계획은 **work/plans**, 구현 후 의미 있는 결과는 **work**에 둡니다.
- 중요한 선택의 이유는 **reference/decisions**에 남깁니다. 일반 작업마다 ADR을 만들지 않습니다.
- 종료된 계획과 더 이상 현재 기준이 아닌 문서는 **archive**로 옮깁니다.

## 기록 원칙

- 공동 문서는 한국어로 관리합니다. 저장소 README는 영어 기본·한국어 번역을 제공합니다.
- 목표·현재 구현·검증·운영 배포를 구분합니다. 제품 목표를 구현 완료로 표시하지 않습니다.
- 같은 사실은 소유 문서에서 갱신하고 다른 문서는 링크합니다. 로드맵을 여러 곳에 복제하지 않습니다.
- 의미 있는 기능·문제 해결은 `work/YYYY-MM-DD-주제.md`에 문제·결정 이유·변경 결과·검증·남은 일을 기록합니다. 커밋과 PR이 있으면 연결하고, 단순 수정 목록은 Git에 맡깁니다.
- 작업이 끝나면 기록과 함께 로드맵·관련 현재 문서를 갱신합니다. 종료 Plan 전체를 작업 기록에 다시 복제하지 않습니다.
- 과거 명세·종료 Plan은 `archive/`에 보관합니다. ADR은 `reference/decisions/`에서 번호와 대체 관계를 유지합니다. 문서 이동 시 저장소 내부 링크를 함께 갱신합니다. evidence 원문과 checksum은 보존합니다.

## 판단과 승인

제품 의도는 최신 사용자 합의 → 현재 PRD → 해당 범위의 최신 ACCEPTED ADR → 승인된 Plan 순서로 판단합니다. 현재 동작은 코드와 테스트로 확인합니다. 작업 기록과 종료 Plan은 새로운 구현 권한이 아닙니다.

PRD의 `APPROVED`는 제품 방향 합의, Plan의 `APPROVED`는 명시된 구현 범위 승인입니다. `IMPLEMENTED`는 코드 반영을 뜻하며 배포·live 검증을 보장하지 않습니다. ADR은 `PROPOSED`·`ACCEPTED`·`SUPERSEDED`·`REJECTED`, 작업 기록은 완료 여부와 실제 검증 결과를 명시합니다. 이전 기록의 날짜와 결과를 현재 값으로 덮어쓰지 않습니다.

문서 변경은 상대 링크·heading anchor·현재/목표 구분과 문서 계약 테스트·`git diff --check`로 검증합니다. 구현 변경은 [프로젝트 프로필](project-profile.md)의 검증·위험 기준과 [AGENTS.md](../AGENTS.md)를 따릅니다.
