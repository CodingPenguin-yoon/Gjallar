# 제품 방향과 문서 구조 재정립

- 날짜: `2026-09-16`
- 상태: `COMPLETED` — 문서 재구성과 문서 검증 완료
- 관련: [PRD](../prd.md), [ADR-013](../reference/decisions/adr-013-unified-proxmox-operations.md)

## 문제와 결정

이전의 observe-first·제한된 실행 중심 명세와 새로 합의한 일상 운영 콘솔 목표가 함께 있어 방향을 읽기 어려웠다. 목표·현재 구현·다음 일·작업 결과를 각각 PRD·아키텍처·로드맵·work에서 찾도록 정리했다.

## 변경 결과

- 새 PRD와 로드맵을 작성하고 이전 명세는 archive/product에 보관했다.
- 상세 아키텍처와 Runbook은 내용을 보존해 최상위 architecture.md·development.md로 이동했다. API·DB·실행 복구 문서는 유지했다.
- ADR-013으로 이전 제품 경계의 부분 대체와 유지할 안전성 원칙을 기록했다.
- 문서 홈·README 두 언어·프로젝트 프로필·작업 지침·문서 계약 검사 경로를 갱신했다.
- 오래된 backend/frontend 소개의 템플릿 프리셋 필수·파일 guard·partial gate 설명을 현재 기준에 맞췄다.
- docs에 남은 Obsidian 로컬 설정을 Git 제외 보관 위치로 이동했다. 과거 evidence 원문은 변경하지 않았다.

## 상세 폴더 재분류

첫 화면에 상세 디렉터리가 많이 남아 있어 API·DB·도메인·작업 흐름과 ADR을 reference, 활성 계획을 work/plans, 과거 evidence를 archive/evidence로 모았다. 문서 홈과 각 인덱스에 역할·갱신 시점·작업 흐름을 명시하고 내부 링크와 문서 검사를 새 경로에 맞췄다. 문서 내용이나 결정의 유효성을 폴더 위치만으로 바꾸지는 않는다.

## 검증

- 문서 계약 테스트 `backend/tests/contracts/test_legacy_backend_cleanup.py`: 10개 통과. 새 경로·한국어 README 링크 검사 포함.
- 과거 live evidence 원문 6개 SHA-256 일치. evidence 인덱스의 이동 링크만 갱신.
- 종료 Plan은 링크 대상 외 본문이 Git 기준과 동일함을 확인.
- `git diff --check`와 두 README의 언어 전환·명령 일치 확인.
- 문서·문서 계약 검사만 변경했으므로 전체 `pnpm run verify`·`pnpm run verify:container`는 실행하지 않았다. runtime 기능이나 live Proxmox 동작을 재검증한 것으로 보지 않는다.

## 남은 일

로드맵의 다음 구현 묶음을 구체화한다. API·DB·인증·복구와 새 실행 경로의 설계는 이번 문서 작업에 포함하지 않는다. 기존 작업 트리의 VM 생성 코드·테스트 변경은 별도 작업으로 보존했다. 커밋·push·배포는 수행하지 않았다.
